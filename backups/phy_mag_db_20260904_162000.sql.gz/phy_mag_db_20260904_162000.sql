-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: phy_mag_db
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','$2y$10$7RatgfhA5OzUd8WU4Qip6ueKZ57IoSg0Z3mh9tgwXIr/ctGSYUHSm','Department Administrator','physics@rkmvm.ac.in','2026-09-04 11:43:33');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_batch` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `edition_year` int NOT NULL DEFAULT '2026',
  `published_date` date NOT NULL,
  `status` enum('published','draft') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `sort_order` int NOT NULL DEFAULT '0',
  `views_count` int NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_edition_status` (`edition_year`,`status`),
  KEY `idx_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (1,'breaking-the-rules-of-time','Breaking The Rules of Time','Breaking the rules of time...','Aman Mondal','UG 2','assets/images/timecrysta.jpg','<p>Imagine a material that never sits still — not even when it\'s supposed to be at rest! Welcome to the weird and wonderful world of Time Crystals. These aren\'t your average shiny rocks. While regular crystals — like diamonds or snowflakes — repeat their structure in space, time crystals repeat themselves in time, like a magical pendulum that keeps ticking forever without ever running out of energy.</p>\n<p>The idea of time crystals was first proposed in 2012 by Nobel Prize-winning physicist Frank Wilczek — purely as a theoretical concept. This strange concept became real when scientists managed to create time crystals in laboratories using ultra-cold atoms, laser manipulations, and even Google\'s quantum computer in 2021.</p>\n<p><strong>Why Are They Special?</strong></p>\n<p>Time crystals break one of nature\'s most fundamental rules: time symmetry. Instead of behaving the same at all times, they choose certain moments to repeat their motion — defying conventional physics. Time crystals don\'t violate energy conservation — they exist in a state of constant oscillation without net energy loss, thanks to quantum mechanics!</p>\n<p>Still in early stages, time crystals aren\'t ready for everyday use. But they hold promise for quantum computing and for pushing the boundaries of what we think is possible in physics. Time Crystals remind us that nature still holds mysteries beyond our grasp — sparking questions, challenging boundaries, and inspiring the next generation of physicists to dream beyond time itself.</p>',2026,'2026-08-15','published',1,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(2,'sc-maglev-technology','SC Maglev Technology','New age technology for faster transport...','Department Contributor','UG 2','assets/images/Maglev.webp','<p>Superconducting Maglev (magnetic levitation) represents a quantum leap in modern high-speed transportation. By utilizing superconducting magnets cooled to cryogenic temperatures, these trains can achieve magnetic levitation and frictionless propulsion along dedicated guideways.</p>\n<p>Unlike conventional high-speed rail that relies on physical wheel-rail contact, SC Maglev eliminates friction entirely, unlocking unprecedented speeds surpassing 600 km/h with whisper-quiet efficiency, enhanced safety, and remarkable energy dynamics powered by electromagnetic principles.</p>',2026,'2026-08-15','published',2,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(3,'grovergpt-quantum-ai','GroverGPT','When AI learns to think like quantum computer...','Arka Biswas','UG 3','assets/images/llm.webp','<p>What happens when artificial intelligence intersects with quantum mechanics? GroverGPT represents a pioneering paradigm where machine learning models borrow algorithmic intuition from quantum computing principles—specifically Grover\'s search algorithm.</p>\n<p>In classical computation, searching through an unsorted database of N items requires O(N) operations. Grover\'s algorithm revolutionized this with quadratic speedup, achieving the search in O(√N) steps through quantum superposition and amplitude amplification.</p>\n<p>By implementing quantum-inspired heuristics within transformer attention heads and high-dimensional vector representations, modern hybrid systems can navigate massive latent spaces far faster, bridging artificial general intelligence concepts with deep physics principles.</p>',2026,'2026-08-15','published',3,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(4,'atomic-clock-gps-satellite','Atomic Clock','Atomic clock and GPS...','Bijan Hazra','UG 2','assets/images/atomicclock.webp','<p>Atomic clocks are the most accurate time and frequency standards known to humanity. Utilizing the hyper-fine transition frequencies of atoms such as Cesium-133 and Rubidium, these devices lose less than one second in tens of millions of years.</p>\n<p>The global positioning system (GPS) that guides our modern world relies directly on atomic clocks onboard orbiting satellites. Because radio signals travel at the speed of light, an error of just one microsecond translates to a spatial deviation of 300 meters! Furthermore, Einstein\'s theories of special and general relativity must be continuously accounted for: time ticks faster at higher gravitational potential, and slower at high orbital velocities.</p>',2026,'2026-08-15','published',4,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(5,'einstein-rosen-bridge','Einstein–Rosen Bridge','Burrowing through the cosmos...','Debarghya Chakladar','UG 2','assets/images/bridge2.jpg','<p>In 1935, Albert Einstein and Nathan Rosen published a groundbreaking theoretical paper demonstrating that general relativity allows for geometrical shortcuts connecting distant points in spacetime: the Einstein–Rosen bridge, colloquially known as a wormhole.</p>\n<p>By connecting two distinct Schwarzschild black hole horizons, such theoretical conduits offer intriguing mathematical bridges across cosmic distances. While traversable wormholes would theoretically require exotic matter with negative energy density to remain stable and open, modern quantum gravity and holographic ER=EPR conjectures continue to reveal profound links between spacetime topology and quantum entanglement.</p>',2026,'2026-08-15','published',5,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(6,'marvel-of-microchips','Marvel of Microchips','The marvelous science behind microchips...','Manaswi Dutta','UG 1','assets/images/microchip.jpg','<p>Behind every smartphone, supercomputer, and modern scientific instrument lies the triumph of solid-state physics: the semiconductor microchip.</p>\n<p>With transistor gate lengths shrunk down to single-digit nanometers, modern silicon fabrication relies on extreme ultraviolet (EUV) lithography and precise quantum tunneling control. The manipulation of energy band gaps in doped semiconductors revolutionized the 20th and 21st centuries, compressing billions of logic gates into an area smaller than a postage stamp.</p>',2026,'2026-08-15','published',6,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(7,'new-age-solar-energy','A new solar energy','To utilize solar energy in new ways...','Surya Mal','UG 1','assets/images/solar.jpg','<p>Solar energy, as we all know, is a great source of renewable energy. Though it has a bunch of advantages; it has some disadvantages also. One of them being how can we use this energy at night. A simple suggestion would be to use batteries to store the energy. But the problem is it is really costly.</p>\n<p>There are two great solutions to this problem: sand batteries and water batteries. For a sand battery, we gather piles of sand at a place and cover it with a thermally isolated system (you can imagine it as a huge thermo flux). At day time, excessive solar energy is used to heat the sand. Sand is cheap, easily available, and stores heat very efficiently. This stored thermal energy is then converted to electricity at night.</p>\n<p>At hilly areas, water batteries (pumped hydroelectric storage) can be used. Two connected water reservoirs are created at different altitudes. Daytime solar energy pumps water up, and at night, gravity-driven hydro turbines generate electricity. They are cost effective, scalable, and provide dependable power.</p>',2026,'2026-08-15','published',7,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(8,'principle-of-least-action','Principle of Least Action','The odyssey of the universe...','Soumyajyoti Roy','UG 1','assets/images/action.jpg','<p>From the trajectory of a thrown ball to Fermat\'s principle of least time in optics and the path integrals of quantum electrodynamics, one profound universal principle stands tall: Nature is inherently economical.</p>\n<p>The Principle of Stationary (Least) Action dictates that out of all conceivable paths a physical system could take through configuration space, it takes the precise path for which the action integral S = ∫ L dt is stationary. Formulated through Euler-Lagrange equations and Hamiltonian mechanics, this principle provides a unified philosophical and mathematical elegance governing classical mechanics, electromagnetism, general relativity, and quantum field theory.</p>',2026,'2026-08-15','published',8,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(9,'dawn-of-agi','Dawn Of AGI','The next biggest tech revolution...','Aritra Mondal','UG 2','assets/images/agi.webp','<p>The journey from artificial intelligence (AI) to artificial general intelligence (AGI) is advancing rapidly. Since 2012, AI has seen exponential progress, with breakthroughs such as deep learning models outpacing human performance on benchmarks like MMLU and ARC. GPT-4 and other transformer models excel at tasks requiring complex reasoning, but they remain limited in generalizing across domains, a key benchmark of AGI.</p>\n<p>AGI is an intelligence system that can learn, adapt, and apply know-how independently across any cognitive activity. A 2026 METR study reveals that current models can complete tasks requiring 60 minutes of expert human effort, a capability that has doubled approximately every 7 months since 2019. However, these models struggle with tasks over 4 hours in duration, with success rates falling below 20%—highlighting a gap in long-term reasoning and memory.</p>\n<p>The shift toward AGI would make automation possible for scientific discoveries as well as creative problem solving and policy development. The development of AGI presents profound opportunities alongside alignment challenges, urging physicists, computer scientists, and ethicists to steer these powerful technologies toward human flourishing.</p>',2026,'2026-08-15','published',9,0,'2026-09-04 11:43:33','2026-09-04 11:43:33'),(10,'the-grandfather-paradox','The Grandfather Paradox','Were you born or not?...','Trishit Malik','UG 2','assets/images/grandfather.jpg','<p>The Grandfather Paradox is one of the most famous paradoxes of theoretical physics, challenging the logical consistency of closed timelike curves (time travel to the past). If a traveler visits the past and prevents their biological grandfather from having children, how could the time traveler ever be born to travel back in the first place?</p>\n<p>In the mid-1980s, Russian astrophysicist Igor Novikov proposed the Novikov Self-Consistency Principle, asserting that the probability of any event causing a paradox is strictly zero. Under this view, only self-consistent histories are physically possible.</p>\n<p>Alternatively, the Many-Worlds interpretation of quantum mechanics suggests that traveling back in time branches into an alternate parallel quantum branch, leaving the original timeline intact. Such paradoxes continue to inspire physicists in unraveling quantum thermodynamics and the true nature of time.</p>',2026,'2026-08-15','published',10,0,'2026-09-04 11:43:33','2026-09-04 11:43:33');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('college_name','Ramakrishna Mission Vidyamandira'),('department_name','Department Of Physics'),('editorial_content','<p>It all began with a fire.</p>\n<p>When early humans lit those first flames, they weren\'t just surviving the cold—they were reaching for something more. A spark of curiosity had been born, and with it began our long journey to understand the world around us.</p>\n<p>That curiosity has never really left us. It\'s what led us to gaze at the stars, to wonder about falling apples, to try and split the atom, and to ask the hardest questions. But the path hasn\'t always been straight or kind. In our rush to discover, we\'ve made mistakes. We\'ve harmed the planet, hurt each other, and sometimes used knowledge in ways that should\'ve made us stop and think.</p>\n<p>Eventually, we found our way back to reason—to science. And through it all, physics stood by us by giving us a new perspective of seeing everything, including ourselves. But we should not forget the bigger task—the task of asking — what does this mean? What comes next?</p>\n<p>Every discovery, every equation, has consequences. Black holes. Lasers. Nuclear energy. These all began as ideas, theories, possibilities. Today, they shape our lives. Some have helped us. Some have hurt us. All of them have changed us.</p>\n<p>That\'s why the implications of science can\'t be an afterthought. They are at the heart of why we do what we do.</p>\n<p>Being a physicist—or even just someone who thinks deeply—means more than asking \"how.\" It means asking \"what now?\" It means understanding that knowledge carries responsibility.</p>\n<p>At the Department of Physics, RKMVM, we believe science is more than solving puzzles. It\'s about understanding our place in the world, and choosing to make that world better.</p>\n<p>Let\'s not just discover. Let\'s think.</p>\n<p>Let\'s not just explain. Let\'s care.</p>'),('editorial_title','The Editorial'),('footer_text','© 2026 Wall magazine — RKMV physics department'),('site_title','Department of Physics - Wall Magazine');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-04 16:20:00
